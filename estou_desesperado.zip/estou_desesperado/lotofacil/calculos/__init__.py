__all__ = ['frequencia', 'ultimo', 'faltantes', 'pesos']
