# combinacoes.csv  

O arquivo possui todas as (3.268.760) combinações possíveis da lotofácil.
