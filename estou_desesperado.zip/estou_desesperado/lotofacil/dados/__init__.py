__all__ = [
			'busca',
			'dados',
			'scrapping_resultados',
			'gerar_combinacoes']
