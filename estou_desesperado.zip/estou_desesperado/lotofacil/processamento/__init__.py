__all__ = [
		   'indice_resultado',
		   'possibilidades',
		   'reajustar_dados',
		   'resultados']
